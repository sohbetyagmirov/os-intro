#/bin/bash
HELLO=HEllo
function hello {
local HELLO=World
echo $HELLO
}
echo $HELLOecho $HELLOecho $HELLO
hello
function hello {
local HELLO=World
echo $HELLO
}
echo $HELLOecho $HELLOecho $HELLO
hello
function hello {
local HELLO=World
echo $HELLO
}
echo $HELLOecho $HELLOecho $HELLO
hello
